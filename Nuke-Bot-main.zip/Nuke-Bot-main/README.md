Requires python and discord.py
